# Sports ORM

Using the SportsORM, complete all the queries and show their results on ```level1.cshtml```, ```level2.cshtml```, and ```level3.cshtml```.

The ERD ```Entity Relationship Diagram``` for the project looks like the following.

<img src="https://raw.githubusercontent.com/wgoode3/SportsORM/master/SportsERD.png" alt="Sports ORM ERD" />